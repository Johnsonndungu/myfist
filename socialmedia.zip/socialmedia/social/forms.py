from .forms import RegistrationForm

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("home")
        
    else:
        form = RegistrationForm()

    return render(request,"accounts/register.html",{"form":form})