from django.shortcuts import render, redirect
from django.contrib.auth.models import login, authenticate
from .models import User
from .forms import RegistrationForm


# Create your views here.
